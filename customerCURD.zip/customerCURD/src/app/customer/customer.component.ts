import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent {

  CustomerArray: any[] = [];
  isResultLoaded: boolean = false;
  isUpdateFormActive: boolean = false;

  customerName: string = "";
  customerSex: string = "";
  customerEmail: string = "";
  customerPhone: string = "";
  customerAddress: string = "";

  currentCustomerID: string = "";

  private apiServer: string = "http://localhost:8081";

  constructor(private http: HttpClient) {

  }

  ngOnInit(){
    this.getAllCustomer();
  }

  public getAllCustomer() {
    this.http.get(`${this.apiServer}/api/customer/all`).subscribe(
      (result: any) => {
        this.isResultLoaded = true;
        console.log(result);
        this.CustomerArray = result;
      }
    );
  }

  public register() {
    let bodyData = {
      "name": this.customerName,
      "sex": this.customerSex,
      "email": this.customerEmail,
      "phone": this.customerPhone,
      "address": this.customerAddress
    };

    this.http.post(`${this.apiServer}/api/customer/save`, bodyData).subscribe((result: any) => {
      console.log(result);
      alert("Register customer successfully!!");
      this.getAllCustomer();
    });
  }

  public save() {
    if (this.currentCustomerID == '') {
      this.register();
    }
  }

  public setUpdate(data: any)
  {
  //  this.name = data.name;
  //  this.address = data.address;
  //  this.mobile = data.mobile;
  //  this.currentEmployeeID = data.id;
  }

  public UpdateRecords()
  {
    // let bodyData = {
    //   "name" : this.name,
    //   "address" : this.address,
    //   "mobile" : this.mobile,
    // };

    // this.http.put("http://127.0.0.1:8000/api/update"+ "/"+ this.currentEmployeeID,bodyData).subscribe((resultData: any)=>
    // {
    //     console.log(resultData);
    //     alert("Employee Registered Updateddd")
    //     this.getAllEmployee();
    //     this.name = '';
    //     this.address = '';
    //     this.mobile  = 0;
    // });
  }

  public setDelete(id: number)
  {


    this.http.delete(`${this.apiServer}/api/customer/delete/${id}`).subscribe((resultData: any)=>
    {
      console.log(resultData);
      alert("Employee Deletedddd");
      this.getAllCustomer();

    });

  }
}
